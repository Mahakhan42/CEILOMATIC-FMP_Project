// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyCISyPBSMbWn0J_J5DQPWQCq2JebN7qGSE",
    authDomain: "ceilomatic-contact-us.firebaseapp.com",
    databaseURL: "https://ceilomatic-contact-us-default-rtdb.firebaseio.com",
    projectId: "ceilomatic-contact-us",
    storageBucket: "ceilomatic-contact-us.appspot.com",
    messagingSenderId: "69008315415",
    appId: "1:69008315415:web:fc20f3b0a6ca3b16983852"
  };

// Initialize Firebase
var app = firebase.initializeApp(firebaseConfig);
// console.log(app.database);

function getvalue(){
    var name = document.getElementById("name");
    var email = document.getElementById("email");
    var message = document.getElementById("Message");
    // console.log(name.value,email.value,message.value);
    var obj = {
        name:name.value,
        email:email.value,
        message:message.value,
    }
    console.log(obj);
     var key = Math.random() * 3245812457;
    firebase.database().ref("Contact Us/Details/" + Math.round(key)).set(obj);

    name.value = "";
    email.value = "";
    message.value = "";
}
function getDataFromDatabase() {
    firebase
      .database()
      .ref("Contact Us/Details/")
      .on("value", function(data) {
        console.log(data.val());
      });
  }
  getDataFromDatabase();
// *********************************************************
  // Book Now Form
  function getData(){
    var Name = document.getElementById("Name");
    var Email = document.getElementById("Email");
    var Phone = document.getElementById("phone");
    var Msg = document.getElementById("message");
    // console.log(Name.value,Email.value,Phone.value,Msg.value);
    var BookNow = {
      Name:Name.value,
      Email:Email.value,
      Phone:Phone.value,
      Msg:Msg.value,
    }
  Name.value = "";
  Email.value = "";
  Phone.value = "";
  Msg.value = "";
    console.log(BookNow);
    firebase.database().ref("Booking Now").push(BookNow);
  }
  getData();
  function getDataDB(){
    firebase
      .database()
      .ref("Booking Now")
      .on("value", function(data) {
        console.log(data.val());
      });
  }
  getDataDB();
  // ******************************************